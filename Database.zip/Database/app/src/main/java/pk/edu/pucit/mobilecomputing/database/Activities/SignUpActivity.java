package pk.edu.pucit.mobilecomputing.database.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pk.edu.pucit.mobilecomputing.database.Database.DBHelper;
import pk.edu.pucit.mobilecomputing.database.R;

public class SignUpActivity extends AppCompatActivity {

    private EditText et_name;
    private EditText et_pass;
    private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        et_name = (EditText) findViewById(R.id.TFusername_signup);
        et_pass = (EditText) findViewById(R.id.TFpassword_signup);
        btn = (Button) findViewById(R.id.Blogin_signup);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String name = et_name.getText().toString();
                String pass = et_pass.getText().toString();
                DBHelper db = new DBHelper(SignUpActivity.this);
                long result = db.insert_login(name,pass);
                if(result >0)
                {
                    Toast.makeText(SignUpActivity.this,"User Registered",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(SignUpActivity.this, LoginActivity.class);
                    finish();
                    startActivity(i);
                }
            }
        });
    }
}
