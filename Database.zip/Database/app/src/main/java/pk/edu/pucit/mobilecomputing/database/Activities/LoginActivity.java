package pk.edu.pucit.mobilecomputing.database.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import pk.edu.pucit.mobilecomputing.database.Database.DBHelper;
import pk.edu.pucit.mobilecomputing.database.Globals;
import pk.edu.pucit.mobilecomputing.database.R;

public class LoginActivity extends AppCompatActivity {

    Button register;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        register  = (Button) findViewById(R.id.button_signup);
        login  = (Button) findViewById(R.id.Blogin);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(i);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText a = (EditText)findViewById(R.id.TFusername) ;
                EditText p = (EditText)findViewById(R.id.TFpassword) ;
                String str = a.getText().toString();
                DBHelper db = new DBHelper(LoginActivity.this);
                Cursor cc = db.getuser(a.getText().toString());
                if(cc.moveToNext())
                {
                    String pass = p.getText().toString();
                    String dbpass = cc.getString(cc.getColumnIndex(DBHelper.PASSWORD));
                    if(pass.equals(dbpass))
                    {
                        Intent i = new Intent(LoginActivity.this, MainActivity.class);
                        finish();
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(LoginActivity.this,"Incorect Pass", Toast.LENGTH_SHORT).show();
                    }

                }
                else {
                    Toast.makeText(LoginActivity.this,"Register first", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }
}
